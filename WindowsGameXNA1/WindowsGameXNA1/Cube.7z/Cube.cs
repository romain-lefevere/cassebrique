﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WindowsGameXNA1
{
    class Cube
    {
        VertexPositionTexture[] vertices;
        VertexBuffer vb;
        IndexBuffer ib;
        int[] indices;

        Texture2D texture;

        public Vector3 Location;
        public Vector3 Scale;

        public float Size;

        protected Cube()
        {
            this.Location = new Vector3(0.0f, 0.0f, 0.0f);
            this.Size = 1f;
        }

        public Cube(float size)
        {
            Size = size;
            this.Location = new Vector3(0.0f, 0.0f, 0.0f);
            this.Scale = new Vector3(1f, 1f, 1f);
        }

        public void Initialize(GraphicsDevice graphics)
        {

            float half = Size /2;

            this.vertices = new VertexPositionTexture[]
            {

                new VertexPositionTexture( new Vector3(half , half , -half)    ,new Vector2(1,0)),
                new VertexPositionTexture( new Vector3(half , -half , -half)   ,new Vector2(1,1)),
                new VertexPositionTexture( new Vector3(-half , -half , -half)  ,new Vector2(0,1)),
                new VertexPositionTexture( new Vector3(-half , half , -half)   ,new Vector2(0,0)),

                new VertexPositionTexture( new Vector3(half , half , half)      ,new Vector2(1,0)),
                new VertexPositionTexture( new Vector3(-half , half , half)    ,new Vector2(1,1)),
                new VertexPositionTexture( new Vector3(-half , -half , half)    ,new Vector2(0,1)),
                new VertexPositionTexture( new Vector3(half , -half , half)    ,new Vector2(0,0)),

                new VertexPositionTexture( new Vector3(half , half , -half)    ,new Vector2(1,0)),
                new VertexPositionTexture( new Vector3(half , half , half)     ,new Vector2(1,1)),
                new VertexPositionTexture( new Vector3(half , -half , half)     ,new Vector2(0,1)),
                new VertexPositionTexture( new Vector3(half , -half , -half)    ,new Vector2(0,0)),

                new VertexPositionTexture( new Vector3(half , -half , -half)    ,new Vector2(1,0)),
                new VertexPositionTexture( new Vector3(half , -half , half)     ,new Vector2(1,1)),
                new VertexPositionTexture( new Vector3(-half , -half , half)    ,new Vector2(0,1)),
                new VertexPositionTexture( new Vector3(-half , -half , -half)   ,new Vector2(0,0)),

                new VertexPositionTexture( new Vector3(-half , -half , -half)   ,new Vector2(1,0)),
                new VertexPositionTexture( new Vector3(-half , -half , half)    ,new Vector2(1,1)),
                new VertexPositionTexture( new Vector3(-half , half , half)    ,new Vector2(0,1)),
                new VertexPositionTexture( new Vector3(-half , half , -half)    ,new Vector2(0,0)),

                new VertexPositionTexture( new Vector3(half , half , half)      ,new Vector2(1,0)),
                new VertexPositionTexture( new Vector3(half , half , -half)     ,new Vector2(1,1)),
                new VertexPositionTexture( new Vector3(-half , half , -half)    ,new Vector2(0,1)),
                new VertexPositionTexture( new Vector3(-half , half , half)     ,new Vector2(0,0))
                
            };


            this.indices = new int[]
            {
                0, 3, 2, 0, 2, 1,
                4, 7, 6, 4,6, 5,
                8, 11, 10,8,10, 9,
                12, 15, 14, 12, 14, 13,
                16, 19, 18,16,18, 17,
                20, 23, 22,20,22, 21            
            };

            this.vb = new VertexBuffer(graphics, typeof(VertexPositionTexture), this.vertices.Length, BufferUsage.WriteOnly);
            vb.SetData(this.vertices);
            this.ib = new IndexBuffer(graphics, IndexElementSize.ThirtyTwoBits, this.indices.Length, BufferUsage.WriteOnly);
            this.ib.SetData(this.indices);
        }

        public void LoadContent(Texture2D tex)
        {
            this.texture = tex;
        }

        public void Draw(BasicEffect effect, GraphicsDevice graphics, Matrix custom)
        {
            Matrix change = Matrix.CreateTranslation(this.Location) * Matrix.CreateScale(this.Scale) * custom;
            effect.World = Matrix.Identity * change;

            effect.Texture = this.texture;
            for (int h = 0; h < 6; h++)
            {
                foreach (EffectPass pass in effect.CurrentTechnique.Passes)
                {
                    pass.Apply();
                    graphics.DrawUserIndexedPrimitives(PrimitiveType.TriangleList, this.vertices, 0, this.vertices.Length, this.indices, h * 6, 2);
                }
            } 
        }


    }
}
